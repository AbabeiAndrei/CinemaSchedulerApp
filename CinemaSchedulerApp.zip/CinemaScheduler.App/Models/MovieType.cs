﻿namespace CinemaScheduler.App.Models
{
    public enum MovieType : short
    {
        Movie2D = 0,
        Movie3D = 1
    }
}