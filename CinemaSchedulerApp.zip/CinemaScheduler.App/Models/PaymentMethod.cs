﻿namespace CinemaScheduler.App.Models
{
    public enum PaymentMethod : short
    {
        None = 0,
        Card = 1,
        Bank = 2
    }
}