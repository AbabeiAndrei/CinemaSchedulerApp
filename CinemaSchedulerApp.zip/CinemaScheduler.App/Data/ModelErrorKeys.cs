﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CinemaScheduler.App.Data
{
    public static class ModelErrorKeys
    {
        public const string IncorectUserOrPass = "incorect-login";
    }
}
