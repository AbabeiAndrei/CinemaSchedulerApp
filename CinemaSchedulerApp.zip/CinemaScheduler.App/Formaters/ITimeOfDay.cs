﻿namespace CinemaScheduler.App.Formaters
{
    public interface ITimeOfDay
    {
        string ShortTime { get; }
    }
}