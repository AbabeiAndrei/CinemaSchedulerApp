﻿namespace CinemaScheduler.App.Formaters
{
    public interface IPriceTag
    {
        string PriceTag { get; }
    }
}
